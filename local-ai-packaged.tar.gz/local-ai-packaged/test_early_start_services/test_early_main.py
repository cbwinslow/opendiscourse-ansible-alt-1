"""
Unit tests for the `main` function in start_services.py

Covers happy paths and edge cases using pytest.
"""

import sys
import types
import builtins
import pytest

from unittest.mock import patch, MagicMock, call

# Absolute import path as per instructions
from start_services import main

@pytest.mark.usefixtures("patch_env")
class TestMain:
    """
    Unit tests for the main() function in start_services.py
    """

    @pytest.fixture(autouse=True)
    def patch_env(self, tmp_path, monkeypatch):
        """
        Shared fixture to patch os, subprocess, shutil, time, and platform
        to avoid side effects and file system changes.
        """
        # Patch os.chdir, os.path.exists, os.path.join
        monkeypatch.setattr("os.chdir", lambda x: None)
        monkeypatch.setattr("os.path.exists", lambda x: True)
        monkeypatch.setattr("os.path.join", lambda *a: "/".join(a))
        # Patch shutil.copyfile
        monkeypatch.setattr("shutil.copyfile", lambda src, dst: None)
        # Patch time.sleep to avoid delays
        monkeypatch.setattr("time.sleep", lambda x: None)
        # Patch platform.system to return 'Linux' by default
        monkeypatch.setattr("platform.system", lambda: "Linux")
        # Patch subprocess.run and subprocess.check_output
        monkeypatch.setattr("subprocess.run", lambda *a, **k: MagicMock(stdout="searxng\n"))
        monkeypatch.setattr("subprocess.check_output", lambda *a, **k: b"deadbeef" * 4)
        # Patch open for docker-compose.yml
        dummy_file = MagicMock()
        dummy_file.read.return_value = "cap_drop: - ALL"
        dummy_file.__enter__.return_value = dummy_file
        monkeypatch.setattr("builtins.open", lambda *a, **k: dummy_file)
        # Patch sys.argv to default
        monkeypatch.setattr(sys, "argv", ["start_services.py"])

    # -------------------- HAPPY PATHS --------------------

    @pytest.mark.happy
    def test_main_default_args(self, monkeypatch):
        """
        Happy path: Test main() with default arguments (profile=cpu, environment=private).
        Ensures all major steps are called in order.
        """
        # Patch all called functions to track calls
        called = []
        monkeypatch.setattr("start_services.clone_supabase_repo", lambda: called.append("clone_supabase_repo"))
        monkeypatch.setattr("start_services.prepare_supabase_env", lambda: called.append("prepare_supabase_env"))
        monkeypatch.setattr("start_services.generate_searxng_secret_key", lambda: called.append("generate_searxng_secret_key"))
        monkeypatch.setattr("start_services.check_and_fix_docker_compose_for_searxng", lambda: called.append("check_and_fix_docker_compose_for_searxng"))
        monkeypatch.setattr("start_services.stop_existing_containers", lambda profile: called.append(f"stop_existing_containers:{profile}"))
        monkeypatch.setattr("start_services.start_supabase", lambda env: called.append(f"start_supabase:{env}"))
        monkeypatch.setattr("start_services.start_local_ai", lambda profile, env: called.append(f"start_local_ai:{profile}:{env}"))
        # Patch print to avoid clutter
        monkeypatch.setattr("builtins.print", lambda *a, **k: None)

        main()

        # Check the call order and arguments
        assert called == [
            "clone_supabase_repo",
            "prepare_supabase_env",
            "generate_searxng_secret_key",
            "check_and_fix_docker_compose_for_searxng",
            "stop_existing_containers:cpu",
            "start_supabase:private",
            "start_local_ai:cpu:private"
        ]

    @pytest.mark.happy
    @pytest.mark.parametrize(
        "profile,environment",
        [
            ("cpu", "private"),
            ("gpu-nvidia", "private"),
            ("gpu-amd", "public"),
            ("none", "public"),
        ]
    )
    def test_main_various_args(self, profile, environment, monkeypatch):
        """
        Happy path: Test main() with all combinations of valid profile/environment.
        """
        called = []
        monkeypatch.setattr("start_services.clone_supabase_repo", lambda: called.append("clone_supabase_repo"))
        monkeypatch.setattr("start_services.prepare_supabase_env", lambda: called.append("prepare_supabase_env"))
        monkeypatch.setattr("start_services.generate_searxng_secret_key", lambda: called.append("generate_searxng_secret_key"))
        monkeypatch.setattr("start_services.check_and_fix_docker_compose_for_searxng", lambda: called.append("check_and_fix_docker_compose_for_searxng"))
        monkeypatch.setattr("start_services.stop_existing_containers", lambda p: called.append(f"stop_existing_containers:{p}"))
        monkeypatch.setattr("start_services.start_supabase", lambda e: called.append(f"start_supabase:{e}"))
        monkeypatch.setattr("start_services.start_local_ai", lambda p, e: called.append(f"start_local_ai:{p}:{e}"))
        monkeypatch.setattr("builtins.print", lambda *a, **k: None)

        # Patch sys.argv to simulate CLI args
        sys.argv = [
            "start_services.py",
            "--profile", profile,
            "--environment", environment
        ]

        main()

        assert called == [
            "clone_supabase_repo",
            "prepare_supabase_env",
            "generate_searxng_secret_key",
            "check_and_fix_docker_compose_for_searxng",
            f"stop_existing_containers:{profile}",
            f"start_supabase:{environment}",
            f"start_local_ai:{profile}:{environment}"
        ]

    # -------------------- EDGE CASES --------------------

    @pytest.mark.edge
    def test_main_profile_none(self, monkeypatch):
        """
        Edge case: Test main() with --profile none (should still call all steps).
        """
        called = []
        monkeypatch.setattr("start_services.clone_supabase_repo", lambda: called.append("clone_supabase_repo"))
        monkeypatch.setattr("start_services.prepare_supabase_env", lambda: called.append("prepare_supabase_env"))
        monkeypatch.setattr("start_services.generate_searxng_secret_key", lambda: called.append("generate_searxng_secret_key"))
        monkeypatch.setattr("start_services.check_and_fix_docker_compose_for_searxng", lambda: called.append("check_and_fix_docker_compose_for_searxng"))
        monkeypatch.setattr("start_services.stop_existing_containers", lambda p: called.append(f"stop_existing_containers:{p}"))
        monkeypatch.setattr("start_services.start_supabase", lambda e: called.append(f"start_supabase:{e}"))
        monkeypatch.setattr("start_services.start_local_ai", lambda p, e: called.append(f"start_local_ai:{p}:{e}"))
        monkeypatch.setattr("builtins.print", lambda *a, **k: None)

        sys.argv = [
            "start_services.py",
            "--profile", "none",
            "--environment", "private"
        ]

        main()

        assert called == [
            "clone_supabase_repo",
            "prepare_supabase_env",
            "generate_searxng_secret_key",
            "check_and_fix_docker_compose_for_searxng",
            "stop_existing_containers:none",
            "start_supabase:private",
            "start_local_ai:none:private"
        ]

    @pytest.mark.edge
    def test_main_environment_public(self, monkeypatch):
        """
        Edge case: Test main() with --environment public.
        """
        called = []
        monkeypatch.setattr("start_services.clone_supabase_repo", lambda: called.append("clone_supabase_repo"))
        monkeypatch.setattr("start_services.prepare_supabase_env", lambda: called.append("prepare_supabase_env"))
        monkeypatch.setattr("start_services.generate_searxng_secret_key", lambda: called.append("generate_searxng_secret_key"))
        monkeypatch.setattr("start_services.check_and_fix_docker_compose_for_searxng", lambda: called.append("check_and_fix_docker_compose_for_searxng"))
        monkeypatch.setattr("start_services.stop_existing_containers", lambda p: called.append(f"stop_existing_containers:{p}"))
        monkeypatch.setattr("start_services.start_supabase", lambda e: called.append(f"start_supabase:{e}"))
        monkeypatch.setattr("start_services.start_local_ai", lambda p, e: called.append(f"start_local_ai:{p}:{e}"))
        monkeypatch.setattr("builtins.print", lambda *a, **k: None)

        sys.argv = [
            "start_services.py",
            "--profile", "cpu",
            "--environment", "public"
        ]

        main()

        assert called == [
            "clone_supabase_repo",
            "prepare_supabase_env",
            "generate_searxng_secret_key",
            "check_and_fix_docker_compose_for_searxng",
            "stop_existing_containers:cpu",
            "start_supabase:public",
            "start_local_ai:cpu:public"
        ]

    @pytest.mark.edge
    def test_main_clone_supabase_repo_raises(self, monkeypatch):
        """
        Edge case: Simulate clone_supabase_repo raising an exception.
        main() should propagate the exception.
        """
        monkeypatch.setattr("start_services.clone_supabase_repo", lambda: (_ for _ in ()).throw(RuntimeError("git error")))
        monkeypatch.setattr("builtins.print", lambda *a, **k: None)
        sys.argv = ["start_services.py"]

        with pytest.raises(RuntimeError, match="git error"):
            main()

    @pytest.mark.edge
    def test_main_prepare_supabase_env_raises(self, monkeypatch):
        """
        Edge case: Simulate prepare_supabase_env raising an exception.
        main() should propagate the exception.
        """
        monkeypatch.setattr("start_services.clone_supabase_repo", lambda: None)
        monkeypatch.setattr("start_services.prepare_supabase_env", lambda: (_ for _ in ()).throw(IOError("env copy error")))
        monkeypatch.setattr("builtins.print", lambda *a, **k: None)
        sys.argv = ["start_services.py"]

        with pytest.raises(IOError, match="env copy error"):
            main()

    @pytest.mark.edge
    def test_main_generate_searxng_secret_key_raises(self, monkeypatch):
        """
        Edge case: Simulate generate_searxng_secret_key raising an exception.
        main() should propagate the exception.
        """
        monkeypatch.setattr("start_services.clone_supabase_repo", lambda: None)
        monkeypatch.setattr("start_services.prepare_supabase_env", lambda: None)
        monkeypatch.setattr("start_services.generate_searxng_secret_key", lambda: (_ for _ in ()).throw(ValueError("secret error")))
        monkeypatch.setattr("builtins.print", lambda *a, **k: None)
        sys.argv = ["start_services.py"]

        with pytest.raises(ValueError, match="secret error"):
            main()

    @pytest.mark.edge
    def test_main_check_and_fix_docker_compose_for_searxng_raises(self, monkeypatch):
        """
        Edge case: Simulate check_and_fix_docker_compose_for_searxng raising an exception.
        main() should propagate the exception.
        """
        monkeypatch.setattr("start_services.clone_supabase_repo", lambda: None)
        monkeypatch.setattr("start_services.prepare_supabase_env", lambda: None)
        monkeypatch.setattr("start_services.generate_searxng_secret_key", lambda: None)
        monkeypatch.setattr("start_services.check_and_fix_docker_compose_for_searxng", lambda: (_ for _ in ()).throw(KeyError("compose error")))
        monkeypatch.setattr("builtins.print", lambda *a, **k: None)
        sys.argv = ["start_services.py"]

        with pytest.raises(KeyError, match="compose error"):
            main()

    @pytest.mark.edge
    def test_main_stop_existing_containers_raises(self, monkeypatch):
        """
        Edge case: Simulate stop_existing_containers raising an exception.
        main() should propagate the exception.
        """
        monkeypatch.setattr("start_services.clone_supabase_repo", lambda: None)
        monkeypatch.setattr("start_services.prepare_supabase_env", lambda: None)
        monkeypatch.setattr("start_services.generate_searxng_secret_key", lambda: None)
        monkeypatch.setattr("start_services.check_and_fix_docker_compose_for_searxng", lambda: None)
        monkeypatch.setattr("start_services.stop_existing_containers", lambda p: (_ for _ in ()).throw(OSError("docker down error")))
        monkeypatch.setattr("builtins.print", lambda *a, **k: None)
        sys.argv = ["start_services.py"]

        with pytest.raises(OSError, match="docker down error"):
            main()

    @pytest.mark.edge
    def test_main_start_supabase_raises(self, monkeypatch):
        """
        Edge case: Simulate start_supabase raising an exception.
        main() should propagate the exception.
        """
        monkeypatch.setattr("start_services.clone_supabase_repo", lambda: None)
        monkeypatch.setattr("start_services.prepare_supabase_env", lambda: None)
        monkeypatch.setattr("start_services.generate_searxng_secret_key", lambda: None)
        monkeypatch.setattr("start_services.check_and_fix_docker_compose_for_searxng", lambda: None)
        monkeypatch.setattr("start_services.stop_existing_containers", lambda p: None)
        monkeypatch.setattr("start_services.start_supabase", lambda e: (_ for _ in ()).throw(RuntimeError("supabase error")))
        monkeypatch.setattr("builtins.print", lambda *a, **k: None)
        sys.argv = ["start_services.py"]

        with pytest.raises(RuntimeError, match="supabase error"):
            main()

    @pytest.mark.edge
    def test_main_start_local_ai_raises(self, monkeypatch):
        """
        Edge case: Simulate start_local_ai raising an exception.
        main() should propagate the exception.
        """
        monkeypatch.setattr("start_services.clone_supabase_repo", lambda: None)
        monkeypatch.setattr("start_services.prepare_supabase_env", lambda: None)
        monkeypatch.setattr("start_services.generate_searxng_secret_key", lambda: None)
        monkeypatch.setattr("start_services.check_and_fix_docker_compose_for_searxng", lambda: None)
        monkeypatch.setattr("start_services.stop_existing_containers", lambda p: None)
        monkeypatch.setattr("start_services.start_supabase", lambda e: None)
        monkeypatch.setattr("start_services.start_local_ai", lambda p, e: (_ for _ in ()).throw(Exception("localai error")))
        monkeypatch.setattr("builtins.print", lambda *a, **k: None)
        sys.argv = ["start_services.py"]

        with pytest.raises(Exception, match="localai error"):
            main()